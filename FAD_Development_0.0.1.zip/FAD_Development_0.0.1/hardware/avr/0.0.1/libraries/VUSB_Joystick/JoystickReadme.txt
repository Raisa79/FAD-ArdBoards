JoystickReadme.txt

This library is for the attiny85 running tiny core Arduino (e.g. the Digispark)

This implements a USB HID joystick device (currently 6 analog and 16 digital)
The code was borrowed mostly from the Digispark Keyboard library and from Rapha�l Ass�nat's code on using an atmega8 as a Nintendo Gamecube/N64 controller to USB bridge: http://www.raphnet.net/electronique/gc_n64_usb/index_en.php
Rapha�l's work is truly marvelous. 

Because most of this code is coming from other projects with GNU GPL, I am letting my modifications inherit the same protection. A copy of this license is included in the source. 

As to the use of this code in Arduino, include DigiJoystick.h as you would any other library. See the included sample for use of the functions. 
